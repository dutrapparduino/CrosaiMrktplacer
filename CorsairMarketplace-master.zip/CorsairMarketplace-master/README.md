<h1 align="center">
<br>
  <img src="./github/logo.png" alt="Corsair" width="120">
  <img src="./github/logoD.png" alt="Corsair" width="120">
<br>
<br>
Corsair Marketplace
</h1>

<p align="center">Application of a Corsair Marketplace, with some of its products, so that the user can add to the cart.</p>

<div align="center" >
  <img src="./github/Corsair.gif" alt="demo-web">
</div>

<hr />


## 🚀 Technologies

This project was developed with the following technologies:

- ✔️ Typescript

- ✔️ React Native

- ✔️ Context API

- ✔️ React Hooks

- ✔️ Styled-components

- ✔️ Axios

- ✔️ Json-server

Made with ♥ by ARTHUR PC :wave: [Get in touch!](https://www.linkedin.com/in/arthurpc03/)
